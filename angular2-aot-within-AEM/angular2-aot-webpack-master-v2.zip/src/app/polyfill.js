"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("core-js/client/shim");
require("zone.js/dist/zone");
require("zone.js/dist/long-stack-trace-zone");
require("../style.css");
