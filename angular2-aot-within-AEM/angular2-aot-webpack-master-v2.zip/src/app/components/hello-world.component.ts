import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'hello-world',
  templateUrl: "./hello-world.template.async.html",
  styleUrls: ["./hello-world.style.css"]
})
export class HelloWorldComponent implements OnInit {
  @Input('aemInstanceId') aemId: string;
  aemContent= {
    aemLabel1 : 'default label 1',
    aemLabel2 : 'default label 2',
    aemLabel3 : 'default label 3'
  };

  ngOnInit() {
    //This should really be a merge, so we don't overwrite defaults if no AEM var exists
    //also window.AEM is for POC purposes only, this should be environment agnostic and loaded through DI
    //  see https://stackoverflow.com/questions/35215112/pass-page-global-variables-into-angular2-app-for-use-with-services
    //  and see https://angular.io/docs/ts/latest/guide/dependency-injection.html
    //  for now this will throw an error on ngc build and pack but its not a hard fail
    this.aemContent = window.AEM.ngContent[this.aemId];
  }
}
