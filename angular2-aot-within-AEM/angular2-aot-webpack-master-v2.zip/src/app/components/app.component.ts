import { Component, ElementRef } from '@angular/core';

@Component({
  selector: 'ng-app',
  template: `<hello-world [aemInstanceId]="aemInstanceId"></hello-world>`,
  styleUrls: ["./hello-world.style.css"]
})
export class AppComponent {
  aemInstanceId:string = 'err';

  constructor (el:ElementRef) {
    this.aemInstanceId = el.nativeElement.getAttribute('data-aeminstanceid');
  }
}
