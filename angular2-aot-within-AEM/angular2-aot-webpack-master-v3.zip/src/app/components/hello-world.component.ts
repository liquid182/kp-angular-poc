import { Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'hello-world',
  templateUrl: "./hello-world.template.async.html",
  styleUrls: ["./hello-world.style.css"]
})
export class HelloWorldComponent implements OnInit {
  @Input('aeminstanceid') aemId: string;
  localContent= {
    label1 : 'default label 1',
    label2 : 'default label 2'
  };
  aemInstanceId = '';

  ngOnInit() {
    this.aemInstanceId = this.aemId;
  }

}
