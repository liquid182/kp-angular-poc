import { Component, ElementRef } from '@angular/core';

@Component({
  selector: 'ng-app',
  template: `<hello-world data-aeminstanceid="instance1"></hello-world>
            <hello-world data-aeminstanceid="instance2"></hello-world>`,
  styleUrls: ["./hello-world.style.css"]
})
export class AppComponent {
  //aemInstanceId:string = 'err';

  constructor (el:ElementRef) {
    //this.aemInstanceId = el.nativeElement.getAttribute('data-aeminstanceid');
  }
}
