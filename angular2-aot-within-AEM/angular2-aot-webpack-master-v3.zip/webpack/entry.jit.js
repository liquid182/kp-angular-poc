'use strict';

module.exports = {
  'main': './app/main.jit.ts',
  'polyfill': './app/polyfill.ts'
};
