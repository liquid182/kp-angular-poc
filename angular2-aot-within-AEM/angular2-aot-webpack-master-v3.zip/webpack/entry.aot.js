'use strict';

module.exports = {
  'main': './app/main.aot.ts',
  'polyfill': './app/polyfill.ts'
};
